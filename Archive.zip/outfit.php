<!--A Design by W3layouts 
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html>
<head>
<title>Youth Fashion A Ecommerce Category Flat Bootstrap Responsive Website Template | Register :: w3layouts</title>
<link href="css/bootstrap-3.1.1.min.css" rel='stylesheet' type='text/css' />
    <link href="css/bootstrap.css" rel="stylesheet" type="text/css" /> 
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery.min.js"></script>
<!-- Custom Theme files -->
<!--theme-style-->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />	
<!--//theme-style-->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Youth Fashion Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href='//fonts.googleapis.com/css?family=Raleway' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Poiret+One' rel='stylesheet' type='text/css'>
<!-- start menu -->
<script src="js/bootstrap.min.js"></script>
    
<script src="js/simpleCart.min.js"> </script>
<!-- slide -->
<script src="js/responsiveslides.min.js"></script>
   <script>
    $(function () {
      $("#slider").responsiveSlides({
      	auto: true,
      	speed: 500,
        namespace: "callbacks",
        pager: true,
      });
    });
  </script>
</head>
<body>
<!--header-->
    <header>
            <?php include "header.php" ;?>	

</header>
			<!---pop-up-box---->  
					<link href="css/popuo-box.css" rel="stylesheet" type="text/css" media="all"/>
					<script src="js/jquery.magnific-popup.js" type="text/javascript"></script>
					<!---//pop-up-box---->
				<div id="small-dialog" class="mfp-hide">
				<div class="search-top">
						<div class="login">
							<form action="#" method="post">
								<input type="submit" value="">
								<input type="text" name="search" value="Type something..." onfocus="this.value = '';" onblur="if (this.value == '') {this.value = '';}">		
							
							</form>
						</div>
						<p>	Shopping</p>
					</div>				
				</div>
				 <script>
						$(document).ready(function() {
						$('.popup-with-zoom-anim').magnificPopup({
							type: 'inline',
							fixedContentPos: false,
							fixedBgPos: true,
							overflowY: 'auto',
							closeBtnInside: true,
							preloader: false,
							midClick: true,
							removalDelay: 300,
							mainClass: 'my-mfp-zoom-in'
						});
																						
						});
				</script>			
	<!---->		
		</div>
	</div>
</div>
<!--//header-->
<div class="breadcrumbs">
		<div class="container">
			<ol class="breadcrumb breadcrumb1 animated wow slideInLeft animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: slideInLeft;">
				<li><a href="index.html"><span class="glyphicon glyphicon-home" aria-hidden="true"></span>Home</a></li>
				<li class="active">Your Clothe</li>
			</ol>
		</div>
	</div>
<a href="userform.php">
<div class="well">
    <div class="row center-block">
    		<h2 style="color:#ffbd4a; text-align:center;">What clothe you want get sugesstion on ? </h2>
    </div>

<div class="row">
    <img class=" img-responsive" src="images/skirt.png" height = 80px width= 80px> <h2 style="color:#ffbd4a; text-align:center;">Skirt</h2>
    </div>
    <br>
    
    <div class="row">
    <img class=" img-responsive" src="images/shirt.png" height = 80px width= 80px> <h2 style="color:#ffbd4a; text-align:center;">Shirt</h2>
    </div>
        <br>

    <div class="row">
    <img class=" img-responsive" src="images/trousers.png" height = 80px width= 80px><h2 style="color:#ffbd4a; text-align:center;">Jeans</h2>
    
    </div><br>
    
    <div class="row">
    <img class=" img-responsive" src="images/pants.png" height = 80px width= 80px><h2 style="color:#ffbd4a; text-align:center;">Trouser</h2>
    
    </div><br>
    

    <div class="row">
    <img class=" img-responsive" src="images/tshirt.png" height = 80px width= 80px><h2 style="color:#ffbd4a; text-align:center;">T-Shirt</h2>
    
    </div><br>
    
    <div class="row">
    <img class=" img-responsive" src="images/coat.png" height = 80px width= 80px><h2 style="color:#ffbd4a; text-align:center;">Jacket</h2>
    
    </div>
    </a>
< br>



</div>


<!-- 		 clothe div ending -->
<!--footer-->
<div class="footer">
	<div class="container">
		<div class="footer-top">
			<div class="col-md-6 top-footer">
				
				<div class="social-icons">
					
				 </div>
			</div>
			
			
<!--footer-->
</body>
</html>