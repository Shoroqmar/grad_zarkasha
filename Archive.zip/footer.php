<!--footer-->
<div class="footer">
	<div class="container">
		<div class="footer-top">
			
			
			


			<div class="clearfix"> </div>	
		</div>	
	</div>
		<div class="footer-bottom">
		<div class="container">
				
		
				<div class="clearfix"> </div>
				<p class="footer-class"> © 2016 Zarkasha . All Rights Reserved</p>
			</div>
	</div>
</div>
<!--footer-->