<?php 

	$conn =mysqli_connect('localhost','root','root','zarkasha');

	